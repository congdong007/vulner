<?php echo  showSectionHead($spTextPanel['About Us']); ?>
<table width="60%" cellspacing="0" cellpadding="0" class="summary">
	<tr><td class="topheader" colspan="2"><?php echo $spText['label']['Developers']?></td></tr>
	<tr>
		<td class="content" style="border-left: none;width: 30%">PHP,MYSQL,AJAX,HTML</td>					
		<td class="contentmid" style="text-align: left;padding-left: 10px">Seo Panel Team, <a href="https://www.seopanel.org/" target="_blank">www.seopanel.org</a></td>
	</tr>
</table>
