


--
-- Seo Panel 4.5.0 changes
--

update `settings` set set_val='4.5.0' WHERE `set_name` LIKE 'SP_VERSION_NUMBER';
