<?php echo $spText['common']['Hello']?> Team,<br><br>

This is a test email sent from <?php echo SP_COMPANY_NAME?><br><br>

<?php echo $spText['common']['Thank you']; ?>,<br>
<?php echo SP_COMPANY_NAME?><br>
<a href="<?php echo SP_WEBPATH?>"><?php echo SP_WEBPATH?></a>