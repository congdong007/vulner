<?php
$themeconf = array(
  'name'    => 'clear',
  'parent'   => 'default',
  'admin_icon_dir' => 'admin/themes/clear/icon',
  'colorscheme' => 'clear',
);
?>
