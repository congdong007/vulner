<section></section>
<div class="container pt-4">
	<div class="col-lg-12">
		<div class="card mt-4 mb-4">
			<div class="card-body">
				<div class="fr-view">
					<?php echo include('about.html') ?>
				</div>
			</div>
		</div>
	</div>
</div>
